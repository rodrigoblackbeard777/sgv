package br.com.sgv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SgvApplication {

	public static void main(String[] args) {
		SpringApplication.run(SgvApplication.class, args);
	}

}
